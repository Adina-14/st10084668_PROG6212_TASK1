﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DLLCalcs;

namespace st10084668_TimeManagementApp
{
    /// <summary>
    /// Interaction logic for Home.xaml
    /// </summary>
    public partial class Home : Window
    {
        //declaring lists

        List<ModuleData> allModules = new List<ModuleData>();
        List<ModuleData> modulePairs = new List<ModuleData>();
        List<selfStudyData> allSSData = new List<selfStudyData>();
        List<ModuleData> filtered;

        //instant class

        ModuleData temp = new ModuleData();
        selfStudyData ssd = new selfStudyData();
      
        public Home()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //Exiting application
            Application.Current.Shutdown();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //disables all dates before today
            DatePicker1.DisplayDateStart = DateTime.Now;

        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            //Declare variable
            bool uniqueCode = true;


            //Exception handling
            try
            {
                //Extracts values from textboxes

                temp.code = tbCode.Text;
                temp.name = tbName.Text;
                temp.credits = Convert.ToInt32(tbCredits.Text);
                temp.classHoursPerWeek = Convert.ToInt32(tbHrsPWk.Text);
                temp.numWeeks = Convert.ToInt32(tbNumWeeks.Text);
                temp.startDate = DateTime.Parse(DatePicker1.Text);
            }
            catch 
            {
                MessageBox.Show("Please ensure that all fields are entered correctly!");
                tbCredits.Clear();
                tbHrsPWk.Clear();
                
            }
            //Checks if module code already exists
            foreach (ModuleData m in allModules)
            {
                if (m.code == tbCode.Text)
                {
                    uniqueCode = false;
                }
            }

            //if code already exists
            if (uniqueCode == false)
            {
                MessageBox.Show("This Module Code already Exists");
            }
            //if fields are left blank
            if (tbName.Text.Length == 0 || tbCode.Text.Length == 0 || tbCredits.Text.Length == 0 || tbHrsPWk.Text.Length == 0 || tbNumWeeks.Text.Length == 0 || DatePicker1.Text.Length == 0)
            {
                MessageBox.Show("Fields cannot be left blank");
            }

            else
            {
                if (uniqueCode == true)//if code does not exist 
                {
                    //confirm if entry before sending to the DGV
                    if (MessageBox.Show("Please verify that the entry is correct", "Confirm Entry", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    {
                       

                        //Calculating self study hours per week
                        temp.ssHoursPerWeek = Calculations.CalcHoursPerWeek(temp.credits, temp.numWeeks, temp.classHoursPerWeek);
                        temp.hoursRemaining = temp.ssHoursPerWeek;

                        //Call method to populate allModules list
                        allModules = ListData.generateModuleList(temp.code,
                                                                temp.name,
                                                                temp.credits,
                                                                temp.classHoursPerWeek,
                                                                temp.ssHoursPerWeek,
                                                                temp.numWeeks,
                                                                temp.startDate);

                        //Call method to populate modulePairs list
                        modulePairs = ListData.generateModulePairsList(temp.code,
                                                                       temp.hoursRemaining);

                        //Clear dataGrid
                        DataGrid1.Items.Clear();

                        //Displaying into DataGrid 1
                        foreach (ModuleData m in allModules)
                        {
                            DataGrid1.Items.Add(m);
                        }
                        //Populating combobox
                        cmbxCode.Items.Add(temp.code);


                        //disable dates before semester start in datePicker2 
                        DatePicker2.DisplayDateStart = temp.startDate;

                        //Clear all textboxes
                        tbCode.Clear();
                        tbName.Clear();
                        tbCredits.Clear();
                        tbHrsPWk.Clear();

                        //Hides components so user cannot change semester details
                        lblWeeks.Visibility = Visibility.Hidden;
                        lblstartDate.Visibility = Visibility.Hidden;

                        tbNumWeeks.Visibility = Visibility.Hidden;
                        DatePicker1.Visibility = Visibility.Hidden;

                        CanVas1.Visibility = Visibility.Hidden;

                    }//end if 
                }//end if uniquecode

            }//end else
        }//btnAdd end

        private void btnHoursWorked_Click(object sender, RoutedEventArgs e)
        {
           

            //Exception Handling
            try
            {
                //Extracts values from textboxes
                ssd.studyDate = DateTime.Parse(DatePicker2.Text);
                ssd.code = cmbxCode.Text;
                ssd.hoursWorked = Convert.ToInt32(tbHoursWorked.Text);
            }
            catch 
            {
                MessageBox.Show("Please ensure that all fields are entered correctl!");
                tbHoursWorked.Clear();
            }

            if (DatePicker2.Text.Length == 0 || cmbxCode.Text.Length == 0 || tbHoursWorked.Text.Length == 0)
            {
                MessageBox.Show("Fields cannot be left blank");
            }
            else
            {
                if (MessageBox.Show("Please verify that the entry is correct", "Confirm Entry", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                   
                    allSSData = ListData.generateAllSSDataList(ssd.studyDate,ssd.code,ssd.hoursWorked);

                    //Clear the data grid
                    DataGrid2.Items.Clear();
                    //Displaying in dataGrid 2
                    foreach (selfStudyData s in allSSData)
                    {
                        DataGrid2.Items.Add(s);
                    }

                    //calculate current week in semester 
                    int currentweek = Calculations.currentWeek(temp.startDate);

                    //calculate week work was done in
                    int workweek = Calculations.workWeek(ssd.studyDate, temp.startDate);



                    //if the work done is in the current week
                    if (currentweek == workweek)
                    {
                        foreach (ModuleData mm in modulePairs)
                        {
                            if (mm.code == cmbxCode.Text) //if the code in the list matches the code in the combobox
                            {
                                mm.hoursRemaining -= ssd.hoursWorked;//subtracts number of hours worked
                                mm.hoursSpentThisWeek += ssd.hoursWorked;//adding hours spent this week
                            }
                        }//end foreach
                    }//end if 


                    //using  LINQ to rearrange data from lower hoursRemaing to higher
                    filtered = (from f in modulePairs
                                orderby f.hoursRemaining ascending
                                select f).ToList();


                    //clear dataGrid 3
                    dataGrid3.Items.Clear();

                    foreach (ModuleData md in filtered)
                    {
                        //populate dataGrid3
                        dataGrid3.Items.Add(md);
                    }
                }//end if
            }//end else
        }//end button click
        
    }//class
}//namespace
