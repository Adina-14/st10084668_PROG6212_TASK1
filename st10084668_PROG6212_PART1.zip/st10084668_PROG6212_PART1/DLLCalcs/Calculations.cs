﻿using System.Data;
using System.Runtime.Intrinsics.X86;

namespace DLLCalcs
{
    //Calculations class
    public static class Calculations
    {
        //calculates number of hours to be done a week
        public static int CalcHoursPerWeek(int credits,int numWeeks,int classHoursPerweek)
        {
            int ssHoursPerWeek;
            ssHoursPerWeek = (int)Math.Round(((double)(credits * 10) / numWeeks) - classHoursPerweek, MidpointRounding.AwayFromZero);
            return ssHoursPerWeek;
        }
        //Method that calculates the current week of the semester
        public static int currentWeek(DateTime startDate)
        {
            int currentWeek;
            currentWeek = (int)Math.Ceiling(((DateTime.Now - startDate).TotalDays+1)/7);
            return currentWeek;
        }
        //Method that calculates the week of the semester that work was done in 
        public static int workWeek(DateTime workdate,DateTime startDate)
        {
            int workWeek;
            workWeek = (int)Math.Ceiling(((workdate-startDate).TotalDays+1)/7);
            return workWeek;
        }
    }

    //Module class
    public class ModuleData
    {
        //variables with getters and setters
        public string code { get; set; }
        public string name { get; set; }
        public int credits { get; set; }
        public int classHoursPerWeek { get; set; }
        public int numWeeks { get; set; }

        public DateTime startDate { get; set; }

        public int ssHoursPerWeek { get; set; }
        public int hoursRemaining { get; set; }
        public int hoursSpentThisWeek { get; set; }

        


    }

    //self study Data class
    public class selfStudyData
    {
        public DateTime studyDate { get; set; }

        public string code { get; set; }
        public int hoursWorked { get; set; }

       
    }


    //Generate list class
    public class ListData
    {
        //Declare lists
        public static List<ModuleData> allModules = new List<ModuleData>();
        public static List<ModuleData> modulePairs = new List<ModuleData>();
        public static List<selfStudyData> allSSData = new List<selfStudyData>();

        //Generates list for allModules
        public static List<ModuleData> generateModuleList(string code ,string name ,int credits,int classHoursPerWeek,int ssHoursPerWeek,int numWeeks,DateTime startDate)
        {
           

            allModules.Add(new ModuleData
            {
                code = code,
                name = name,
                credits = credits,
                classHoursPerWeek = classHoursPerWeek,
                ssHoursPerWeek = ssHoursPerWeek,
                numWeeks = numWeeks,
                startDate = startDate
            });
            return allModules;
        }//end first method

        //Generates list for modulePairs 
        public static List<ModuleData> generateModulePairsList(string code ,int hoursRemaining)
        {
          
            modulePairs.Add(new ModuleData
            {
                code = code,
                hoursSpentThisWeek = 0,
                hoursRemaining = hoursRemaining
            });
            return modulePairs;
        }//end second method

        //Generates list for allSSData
        public static List<selfStudyData> generateAllSSDataList(DateTime studyDate,string code ,int hoursWorked)
        {
            
            allSSData.Add(new selfStudyData
            {
                studyDate = studyDate,
                code = code,
                hoursWorked = hoursWorked
            });
            return allSSData;
        }//end third method
    }
}